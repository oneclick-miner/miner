Everything is ready!
********************
Simply click on the Start.exe, no more settings are necessary.


Alles ist bereit!
********************
Klicke einfach auf die Start.exe um loszulegen. Es ist keine weiteren Einstellungen mehr nötig.


¡Todo está listo!
********************
Simplemente haga clic en Start.exe para comenzar. No son necesarias más configuraciones.

